export class Game {
    id:string;
    name:string;
    amount:number;
}
