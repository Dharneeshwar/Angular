import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Game } from '../model/game';
@Injectable({
  providedIn: 'root'
})
export class GameService {
  url:string='http://localhost:3000/games';
  constructor(private http:HttpClient) { }
  // getPlayList() method retrive all the records from gamelist.json file and return it
  getPlayList()
  {
    return this.http.get<Game[]>(this.url);
  }
   // getById() method retrive the record of specific id from gamelist.json file and return it
  getById(id:string){
    return this.http.get<Game>(this.url+"/"+id);
  }
}
