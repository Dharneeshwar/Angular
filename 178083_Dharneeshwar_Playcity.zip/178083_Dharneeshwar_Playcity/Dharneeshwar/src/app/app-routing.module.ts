import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PlayComponent } from './play/play.component';
import { SuccessComponent } from './success/success.component';

const routes: Routes = [
  {path:'play',component:PlayComponent},
  {path:'success/:id',component:SuccessComponent},
  {path:' ',redirectTo:"play"}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
