import { Component, OnInit } from '@angular/core';
import { GameService } from '../service/game.service';
import { Game } from '../model/game';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-play',
  templateUrl: './play.component.html',
  styleUrls: ['./play.component.css']
})
export class PlayComponent implements OnInit {
  searchData:any='';
games:Game[];
  constructor(private gameService:GameService,private router:Router) { }

  ngOnInit() {
    this.gameService.getPlayList().subscribe((data:Game[])=>{this.games=data
      console.log(this.games+" "+this.games.length)});
  }

}
