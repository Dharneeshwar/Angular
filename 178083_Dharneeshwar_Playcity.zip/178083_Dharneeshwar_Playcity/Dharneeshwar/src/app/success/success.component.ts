import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { GameService } from '../service/game.service';
import { Game } from '../model/game';

@Component({
  selector: 'app-success',
  templateUrl: './success.component.html',
  styleUrls: ['./success.component.css']
})
export class SuccessComponent implements OnInit {
  gameData:Game={"id":'',"name":'',"amount":0};
 cardBalance=600.00;
  message:string='';
  constructor(private gameService:GameService,private router:Router,private route:ActivatedRoute) { }
//While loading this page we are retriving record of selected game and displaying message as per the status of user card balance
  ngOnInit() {
    this.route.params.subscribe((params)=>{this.gameService.getById(params['id']).subscribe((res)=>{
      this.gameData=res;
    });
  
  });
if(this.gameData.amount<=this.cardBalance){
  this.cardBalance=this.cardBalance-this.gameData.amount;
}
 
  }

}
